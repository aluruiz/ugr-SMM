/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica7_paint2d;

/**
 *
 * @author Shiri
 */
public enum Herramientas {
    punto, linea, rectangulo, elipse; 
}
